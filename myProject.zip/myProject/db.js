const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // MySQL 사용자 이름으로 변경
    password: 'whddns135@', // MySQL 비밀번호로 변경
    database: 'login_db' // 위에서 만든 데이터베이스 이름
});

connection.connect(err => {
    if (err) {
        console.error('MySQL 연결 오류: ' + err.stack);
        return;
    }
    console.log('MySQL에 연결되었습니다. ID: ' + connection.threadId);
});

module.exports = connection;