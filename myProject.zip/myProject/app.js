const express = require('express');
const path = require('path');
const connection = require('./db');
const bcrypt = require('bcryptjs');

const app = express();
const port = 3000;

// JSON 요청 본문을 파싱하기 위한 미들웨어
app.use(express.json());

// 'public' 폴더를 정적 파일 폴더로 설정합니다.
// 이 설정으로 CSS, JS, 이미지 파일 등을 자동으로 서빙할 수 있습니다.
app.use(express.static(path.join(__dirname, 'public')));

// 루트 URL('/')로 GET 요청이 오면 public 폴더의 index.html 파일을 보냅니다.
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// '/about' URL로 GET 요청이 오면 public 폴더의 about.html 파일을 보냅니다.
app.get('/about', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'about.html'));
});

// --- 로그인 데이터베이스 API 라우트 ---

// 회원가입 라우트
app.post('/register', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).send('사용자 이름과 비밀번호를 모두 입력해야 합니다.');
    }

    try {
        // 비밀번호 암호화
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // 데이터베이스에 사용자 저장
        const sql = 'INSERT INTO users (username, password) VALUES (?, ?)';
        connection.query(sql, [username, hashedPassword], (err, result) => {
            if (err) {
                if (err.code === 'ER_DUP_ENTRY') {
                    return res.status(409).send('이미 존재하는 사용자 이름입니다.');
                }
                console.error('회원가입 오류: ', err);
                return res.status(500).send('서버 오류가 발생했습니다.');
            }
            res.status(201).send('회원가입이 성공적으로 완료되었습니다!');
        });
    } catch (err) {
        console.error('비밀번호 암호화 오류: ', err);
        res.status(500).send('서버 오류가 발생했습니다.');
    }
});

// 로그인 라우트
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).send('사용자 이름과 비밀번호를 모두 입력해야 합니다.');
    }

    // 데이터베이스에서 사용자 찾기
    const sql = 'SELECT * FROM users WHERE username = ?';
    connection.query(sql, [username], async (err, results) => {
        if (err) {
            console.error('로그인 오류: ', err);
            return res.status(500).send('서버 오류가 발생했습니다.');
        }

        if (results.length === 0) {
            return res.status(401).send('존재하지 않는 사용자입니다.');
        }

        const user = results[0];

        // 비밀번호 비교
        const isMatch = await bcrypt.compare(password, user.password);

        if (!isMatch) {
            return res.status(401).send('비밀번호가 일치하지 않습니다.');
        }

        res.status(200).send('로그인 성공!');
    });
});

// 서버를 시작하고 3000번 포트에서 요청을 기다립니다.
app.listen(port, () => {
    console.log(`서버가 http://localhost:${port} 에서 실행 중입니다.`);
});