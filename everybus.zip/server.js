// server.js

// 1. 필요한 모듈 가져오기
const express = require('express');
const mysql = require('mysql2/promise'); // Promise 기반의 mysql2 라이브러리
const cors = require('cors');

// 2. Express 앱 생성 및 설정
const app = express();
const PORT = 5000; // 프론트엔드가 요청할 포트 번호

// CORS 미들웨어 설정: localhost:3000에서의 요청을 허용
app.use(cors({ origin: 'http://localhost:3000' }));

// 3. 데이터베이스 연결 풀(Pool) 생성
// 여러 요청을 효율적으로 처리하기 위해 connection pool을 사용합니다.
const dbPool = mysql.createPool({
    host: 'localhost',
    user: 'root', // 본인의 MySQL 사용자 이름
    password: 'whddns135@', // 본인의 MySQL 비밀번호로 변경하세요!
    database: 'everybus',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// 4. API 엔드포인트(라우트) 구현
// ===================================

/**
 * @api {get} /stops
 * @description 모든 버스 정류장 목록을 조회합니다.
 */
app.get('/stops', async (req, res) => {
    try {
        console.log(`[${new Date().toISOString()}] GET /stops 요청 수신`);
        const [rows] = await dbPool.query('SELECT id, name, lat, lng FROM stops');
        res.status(200).json(rows);
    } catch (error) {
        console.error('DB 쿼리 오류:', error);
        res.status(500).json({ message: '서버 내부 오류가 발생했습니다.' });
    }
});

/**
 * @api {get} /vehicles
 * @description 현재 운행 중인 모든 버스의 실시간 위치를 조회합니다.
 */
app.get('/vehicles', async (req, res) => {
    try {
        console.log(`[${new Date().toISOString()}] GET /vehicles 요청 수신`);
        // 실제로는 이 부분에서 외부 GPS 시스템 연동, 캐시(Redis) 조회 등의 로직이 들어갑니다.
        // 여기서는 DB에 저장된 최신 위치를 조회하는 것으로 구현합니다.
        const [rows] = await dbPool.query('SELECT id, route, lat, lng, heading, updatedAt FROM vehicles');
        res.status(200).json(rows);
    } catch (error) {
        console.error('DB 쿼리 오류:', error);
        res.status(500).json({ message: '서버 내부 오류가 발생했습니다.' });
    }
});


// 5. 서버 실행
app.listen(PORT, () => {
    console.log(`✅ EveryBus 백엔드 서버가 포트 ${PORT}에서 실행 중입니다.`);
    console.log(`➡️  http://localhost:${PORT}`);
});

// (선택사항) 실제 상황을 위한 버스 위치 시뮬레이션
// 10초마다 '경기71사1234' 버스의 위치를 약간씩 랜덤하게 이동시킵니다.
setInterval(async () => {
    try {
        const newLat = 37.2975 + (Math.random() - 0.5) * 0.001;
        const newLng = 126.8370 + (Math.random() - 0.5) * 0.001;
        const newHeading = Math.floor(Math.random() * 360);
        
        await dbPool.query(
            'UPDATE vehicles SET lat = ?, lng = ?, heading = ? WHERE id = ?',
            [newLat, newLng, newHeading, '경기71사1234']
        );
        console.log(`[시뮬레이션] '경기71사1234' 버스 위치 업데이트 완료`);
    } catch (error) {
        console.error('[시뮬레이션] 오류:', error);
    }
}, 10000); // 10초